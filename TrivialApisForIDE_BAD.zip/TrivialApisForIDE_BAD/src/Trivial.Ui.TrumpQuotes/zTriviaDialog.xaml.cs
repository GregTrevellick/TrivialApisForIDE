﻿using System.Diagnostics;
using System.Windows;
using System.Windows.Navigation;
using Microsoft.VisualStudio.PlatformUI;

namespace Ui.TrumpQuotes
{
    public partial class TriviaDialog : DialogWindow
    {
        //// Use this constructor to provide a Help button and F1 support.
        //public WpfDialogDw(string helpTopic) : base(helpTopic)
        //{
        //    InitializeComponent();
        //}
        //

        public TriviaDialog()
        {
            InitializeComponent();

            SizeToContent = SizeToContent.WidthAndHeight;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
        }

        private void AppHyperlink1_RequestNavigate(object sender, RequestNavigateEventArgs e)
        {
            Process.Start(new ProcessStartInfo(e.Uri.AbsoluteUri));
            e.Handled = true;
        }
    }
}