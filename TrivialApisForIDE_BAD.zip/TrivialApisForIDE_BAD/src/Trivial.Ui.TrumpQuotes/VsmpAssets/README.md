[GitHubRepoURL]: https://github.com/GregTrevellick/SolutionOpenPopUp
[GitHubRepoIssuesURL]: https://github.com/GregTrevellick/SolutionOpenPopUp/issues
[GitHubRepoPullRequestsURL]: https://github.com/GregTrevellick/SolutionOpenPopUp/pulls

# Trump Quotes

Enlighten your day with an insightful random quote from Donald Trump when opening a solution file.

- This is truly tremendous. A wonderful thing. It deserves a review below.

- Trust me folks, I think this [guy's](https://www.tronalddump.io) gonna be alright.

- Inspired by [Phil Haack's Encourage](https://marketplace.visualstudio.com/items?itemName=Haacked.Encourage) extension. 

- Contributions to this project are welcome, especially from Mexicans, by raising an [Issue][GitHubRepoIssuesURL] or submitting a [Pull Request][GitHubRepoPullRequestsURL].