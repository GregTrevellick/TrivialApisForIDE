﻿namespace Trivial.Entities
{
    public enum AppName
    {
        TrumpQuotes,
        NumericTrivia
    }
}
