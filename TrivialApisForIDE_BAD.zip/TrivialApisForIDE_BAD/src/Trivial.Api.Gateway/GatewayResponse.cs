﻿namespace Trivial.Api.Gateway
{
    public class GatewayResponse
    {
        public string Text { get; set; }
        public string Attribution { get; set; }
        public string LinkUri { get; set; }
        public string LinkText { get; set; }
    }
}
