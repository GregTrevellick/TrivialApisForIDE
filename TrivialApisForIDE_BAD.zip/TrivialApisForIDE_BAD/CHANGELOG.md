# Change log

These are the incremental changes to each version that has been released on the official Visual Studio Market Place (aka Visual Studio Gallery).

Individual releases are tagged as such in GitHub.

## 1.0.xx
**2017-mm-dd**
- [x] Initial release

<!--
 https://github.com/Microsoft/UnitTestBoilerplateGenerator/blob/master/src/CreateUnitTestBoilerplateDialog.xaml
 http://www.c-sharpcorner.com/UploadFile/mahakgupta/simple-data-binding-in-wpf/
 https://github.com/onlyutkarsh/XamlDialogInVSExtensionDemo
 https://stackoverflow.com/questions/17233651/wpf-data-binding-label-content
 https://msdn.microsoft.com/en-us/library/ff770546.aspx?f=255&MSPPError=-2147217396
-->
